/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diary;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.stage.FileChooser;
import javax.imageio.ImageIO;

/**
 * FXML Controller class
 *
 * @author jannat
 */
public class LoginController implements Initializable {

    /**
     * Initializes the controller class.
     */
    public Diary ob = new Diary();
    @FXML
    private Button backlogin;

     @FXML
    private TextArea eventshow;
    
    @FXML
    private void back(ActionEvent event) throws IOException {
        ob.showLoginPage();
    }

    @FXML
    private DatePicker datepick;
    @FXML
    private Label showdate;

    @FXML
    private Button addevent;

    @FXML
    private Button showevent;

    @FXML
    private TextField sf;

    @FXML
    private ImageView viewer;

    BufferedImage currpic;

    @FXML
    private void showDate() throws IOException {
        LocalDate ld = datepick.getValue();
        showdate.setText(ld.toString());
    }
    @FXML
    private void addEvent(ActionEvent event) throws IOException {
        
        BufferedWriter bw;
        BufferedReader br;
        showDate();
        String s=showdate.getText()+ob.username+".txt";
        File f=new File("F:\\CSE 2-1\\Java Sessional\\Offline\\Diary",s);
        if(f.exists()){
            try (FileReader fr = new FileReader(f)){
                br = new BufferedReader(fr);
                FileWriter fw = new FileWriter(f,true);
                bw = new BufferedWriter(fw);
                String p=new String(Files.readAllBytes(Paths.get("F:\\CSE 2-1\\Java Sessional\\Offline\\Diary" + "\\" +s)));
                eventshow.setText(p);
                bw.write(eventshow.getText()+"\n");
                
                br.close();
                bw.close();
                fr.close();
                fw.close();
            }  
        }
        else {
            try(FileWriter fw=new FileWriter(f)){
                bw = new BufferedWriter(fw);
                
                bw.write(eventshow.getText()+"\n");
                bw.close();
                fw.close();
            }
        }
        
    }

    @FXML
    private void showEvent(ActionEvent event) throws IOException {
        //BufferedWriter bw;
        BufferedReader br;
        showDate();
        String s=showdate.getText()+ob.username+".txt";
        File f=new File("F:\\CSE 2-1\\Java Sessional\\Offline\\Diary",s);
        if(f.exists()){
            try (FileReader fr = new FileReader(f)){
                br = new BufferedReader(fr);
                //FileWriter fw = new FileWriter(f,true);
                //bw = new BufferedWriter(fw);
                String p=new String(Files.readAllBytes(Paths.get("F:\\CSE 2-1\\Java Sessional\\Offline\\Diary" + "\\" +s)));
                eventshow.setText(p);
             
                //bw.write(eventshow.getText()+"\n");
                
                br.close();
                //bw.close();
                fr.close();
                //fw.close();
            }  
        }
        
        
    }
    

    @FXML
    private void choose(ActionEvent e) throws IOException {
        FileChooser fc = new FileChooser();
        fc.setInitialDirectory(new File("C:\\Users\\user\\Desktop"));
        fc.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Image Files", "*.jpg"));
        File selected_file = fc.showOpenDialog(null);
        sf.setText(selected_file.getAbsolutePath());
        currpic = ImageIO.read(selected_file);
        WritableImage selected_pic = SwingFXUtils.toFXImage(currpic, null);
        viewer.setImage(selected_pic);
    }
    @FXML
    void docancel() throws IOException{
        ImageIO.write(currpic, "png", new File("temp.png"));
            WritableImage temp2 = SwingFXUtils.toFXImage(currpic, null);
            viewer.setImage(temp2);
    }
    
    @FXML
    void makegrayscale() throws IOException {
        int h = currpic.getHeight();
        int w = currpic.getWidth();
        BufferedImage newImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        for (int i = 0; i < w; i++) {
            for (int j = 0; j < h; j++) {
                int rgb = currpic.getRGB(i, j);
                int r = (rgb >> 16) & 0xff;
                int g = (rgb >> 8) & 0xff;
                int b = rgb & 0xff;
                int k = (int) (.56 * g + .33 * r + .11 * b);
                newImage.setRGB(i, j, (0xff000000 | k << 16 | k << 8 | k));
            }
        }
        ImageIO.write(newImage, "png", new File("temp.png"));
            WritableImage temp2 = SwingFXUtils.toFXImage(newImage, null);
            viewer.setImage(temp2);
    }
    @FXML
    void makesepia() throws IOException {
        int h = currpic.getHeight();
        int w = currpic.getWidth();
        BufferedImage newImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        for (int i = 0; i < w; i++) {
            for (int j = 0; j < h; j++) {
                int rgb = currpic.getRGB(i, j);
                int r = (rgb >> 16) & 0xff;
                int g = (rgb >> 8) & 0xff;
                int b = rgb & 0xff;
                r = Math.min((int) (.393 * r + .769 * g + .189 * b), 255);
                g = Math.min((int) (.349 * r + .686 * g + .168 * b), 255);
                b = Math.min((int) (.272 * r + .534 * g + .131 * b), 255);
                newImage.setRGB(i, j, (0xff000000 | r << 16 | g << 8 | b));
            }
        }
        ImageIO.write(newImage, "png", new File("temp.png"));
            WritableImage temp2 = SwingFXUtils.toFXImage(newImage, null);
            viewer.setImage(temp2);
    }
    @FXML
    void makeblur() throws IOException {
        int h = currpic.getHeight();
        int w = currpic.getWidth();
        BufferedImage newImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        for (int y = 1; y < w - 1; y++) {
            for (int x = 1; x < h - 1; x++) {
                int rs = 0;
                int gs = 0;
                int bs = 0;
                for (int k = -1; k <= 1; k++) {
                    for (int j = -1; j <= 1; j++) {
                        int rgb = currpic.getRGB(y + k, x + j);
                        int r = (rgb >> 16) & 0xff;
                        int g = (rgb >> 8) & 0xff;
                        int b = rgb & 0xff;
                        rs += r;
                        gs += g;
                        bs += b;
                    }
                }
                rs /= 9;
                gs /= 9;
                bs /= 9;
                newImage.setRGB(y, x, 0xff000000 | rs << 16 | gs << 8 | bs);
            }
        }
        ImageIO.write(newImage, "png", new File("temp.png"));
            WritableImage temp2 = SwingFXUtils.toFXImage(newImage, null);
            viewer.setImage(temp2);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
