/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diary;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author jannat
 */
public class CreateaccountController implements Initializable {

    /**
     * Initializes the controller class.
     */
    public Diary ob = new Diary();
    @FXML
    private Button backcreateaccount;

    @FXML
    private Button signup;

    @FXML
    private TextField username;

    @FXML
    private PasswordField password;

    @FXML
    private void back(ActionEvent event) throws IOException {
        ob.showLoginPage();
    }

    @FXML
    private void createacc(ActionEvent e) throws IOException {
        BufferedReader br;
        FileWriter fw;
        BufferedWriter bw;
        try (FileReader fr = new FileReader("F:\\CSE 2-1\\Java Sessional\\Offline\\Diary\\acc.txt")) {
            br = new BufferedReader(fr);
            fw = new FileWriter("F:\\CSE 2-1\\Java Sessional\\Offline\\Diary\\acc.txt", true);
            bw = new BufferedWriter(fw);
            while (true) {
                String usernametemp = br.readLine();
                String passwordtemp = br.readLine();
                if (usernametemp == null) {
                    bw.write(username.getText() + "\n");
                    bw.write(password.getText() + "\n");
                    ob.showBrowser();
                    break;
                }
                /*else if (username.getText().equals(usernametemp)) {
                    error_message.setVisible(true);
                    break;
                }*/
            }
        }
        br.close();
        bw.close();
        //fr.close();
        fw.close();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
