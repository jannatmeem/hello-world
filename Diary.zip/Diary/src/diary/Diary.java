/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diary;

import java.io.IOException;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author jannat
 */
public class Diary extends Application {
    
    static Stage primary;
    static String username;
    @Override
    public void start(Stage meem) throws IOException {
        primary=meem;
        showLoginPage();
        //showBrowser();
    }
    public void showLoginPage() throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("front.fxml"));
        
        Scene scene = new Scene(root,900,600);
        
        primary.setTitle("My Diary");
        primary.setScene(scene);
        primary.show();
    }
    
    public void showBrowser() throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
             
            Scene scene1 = new Scene(root,900,600);
            primary.setTitle("My Diary");
            primary.setScene(scene1);
            primary.show();
    }
    
    public void createaccount() throws IOException{
         Parent root = FXMLLoader.load(getClass().getResource("Createaccount.fxml"));
             
            Scene scene1 = new Scene(root,900,600);
            //abc.setScene(scene1);
            primary.setTitle("My Diary");
            primary.setScene(scene1);
            primary.show();
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
