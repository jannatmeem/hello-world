/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package diary;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author jannat
 */
public class FrontController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private Button loginbtn;

    @FXML
    private Button createbtn;

    public Diary ob = new Diary();
    @FXML
    private TextField user;

    @FXML
    private PasswordField pass;
    @FXML
    private Label lblvalidity;

    @FXML
    private void login(ActionEvent event) throws IOException {
        try (FileReader fr = new FileReader("F:\\CSE 2-1\\Java Sessional\\Offline\\Diary\\acc.txt");
                BufferedReader br = new BufferedReader(fr)) {
            while (true) {
                String usernametemp = br.readLine();
                String passwordtemp = br.readLine();
                if (usernametemp == null/* || user_name_text.getText() != ""*/) {
                    lblvalidity.setText("Invalid login");
                    break;
                } else if (user.getText().equals(usernametemp)) {
                    if (pass.getText().equals(passwordtemp)) {
                        ob.username=user.getText();
                        ob.showBrowser();
                    } else {
                        lblvalidity.setText("Invalid login");
                        break;
                    }
                }
            }
        }

    }

    @FXML
    private void create(ActionEvent event) throws IOException {
        ob.createaccount();
    }

    @FXML
    private DatePicker datepick;
    @FXML
    private Label showdate;

    @FXML
    private Button addevent;

    @FXML
    private Button showevent;

    @FXML
    private void showDate(ActionEvent event) throws IOException {
        LocalDate ld = datepick.getValue();
        showdate.setText(ld.toString());
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
