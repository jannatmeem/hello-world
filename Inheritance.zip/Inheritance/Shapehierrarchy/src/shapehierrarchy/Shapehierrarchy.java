/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shapehierrarchy;

/**
 *
 * @author jannat
 */
abstract class Shape{
    abstract double area();
};
abstract class TwoDShape extends Shape{

};
abstract class ThreeDShape extends Shape{
    abstract double volume();
};
class Circle extends TwoDShape{
    private double r;
    Circle(double x)
    {
        r=x;
    }
    @Override
    double area(){
        return 3.14*r*r;
    }
};
class Rectangle extends TwoDShape{
    private double a;
    private double b;
    Rectangle(double x,double y)
    {
        a=x;
        b=y;
    }
    @Override
    double area(){
        return a*b;
    }
};
class Triangle extends TwoDShape{
    private double a;
    private double b;
    Triangle(double x,double y)
    {
        a=x;
        b=y;
    }
    @Override
    double area(){
        return 0.5*a*b;
    }
};
class Sphere extends ThreeDShape{
    private double q;
    Sphere(double x)
    {
        q=x;
    }
    @Override
    double area()
    {
        return 4*3.14*q*q;
    }
    double volume()
    {
        return (4/3)*3.14*q*q*q;
    }
};
class Cube extends ThreeDShape{
    private double a;
    private double b;
    private double c;
    Cube(double x,double y,double z)
    {
        a=x;
        b=y;
        c=z;
    }
    @Override
    double area()
    {
        return 2*(a*b+b*c+c*a);
    }
    double volume()
    {
        return a*b*c;
    }
};
public class Shapehierrarchy {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Shape abc;
        ThreeDShape thr;
        Circle cir=new Circle(5);
        Rectangle rec=new Rectangle(2,3);
        Triangle tri=new Triangle(4,5);
        Sphere sp=new Sphere(5);
        Cube cub=new Cube(3,4,5);
        abc=cir;
        System.out.println("Area of circle is:"+abc.area());
        abc=rec;
        System.out.println("Area of rectangle is:"+abc.area());
        abc=tri;
        System.out.println("Area of triangle is:"+abc.area());
        abc=sp;
        System.out.println("Area of sphere is:"+abc.area());
        abc=cub;
        System.out.println("Area of cube is:"+abc.area());
        thr=sp;
        System.out.println("Volume of sphere is:"+thr.volume());
        thr=cub;
        System.out.println("Volume of cube is:"+thr.volume());
    }
    
}
