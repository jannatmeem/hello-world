/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enemyshiptesting;

/**
 *
 * @author jannat
 */
public class BigUFOEnemyShip extends UFOEnemyShip {
    BigUFOEnemyShip()
    {
        setName("Big UFO Enemy Ship");
        setDamage(40.0);
    }
}
