/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accountsystem;

/**
 *
 * @author jannat
 */
class Account{
    private int accountNumber;
    private String holderName;
    private String holderType;
    Account(int a,String b,String c){
        accountNumber=a;
        holderName=b;
        holderType=c;
    }
    public int getAccount(){ return accountNumber;}
    public String getHolder(){return holderName;}
    public String getType(){return holderType;}
};
class StudentAccount extends Account{
    private String institute;
    private String status;
    StudentAccount(int a,String b,String c,String d,String e){
        super(a,b,c);
        institute=d;
        status=e;
    }
    public String getinst(){return institute;}
    public String getstatus(){ return status;}
    void show(){
        System.out.println("accountNumber:"+getAccount()+" holderName:"+getHolder()+" holderType:"+getType()+" institute:"+institute+" status:"+status);
    }
};
class BankAccount extends Account{
    private String bankName;
    private double balance;
    BankAccount(int a,String b,String c,String d,double e){
        super(a,b,c);
        bankName=d;
        balance=e;
    }
    public String getbank(){return bankName;}
    public double getbalance(){ return balance;}
    void setbalance(double x){balance=x;}
};
class SavingsAccount extends BankAccount{
    private double depositAmount;
    private double withdrawalAmount;
    private int passbookNo;
    SavingsAccount(int a,String b,String c,String d,double e,double f,double g,int h){
        super(a,b,c,d,e);
        depositAmount=f;
        withdrawalAmount=g;
        passbookNo=h;
    }
    void show(){
        System.out.println("accountNumber:"+getAccount()+" holderName:"+getHolder()+" holderType:"+getType()+" bankName:"+getbank()+" balance:"+getbalance()+" depositAmount:"+depositAmount+" withdrawalAmount:"+withdrawalAmount+" passbookNo"+passbookNo);
    }
    void deposit(){
        double i=getbalance()+depositAmount;
        setbalance(i);
    }
    void withdraw(){
        if(getbalance()<withdrawalAmount) setbalance(getbalance());
        else{
            double interest=withdrawalAmount*0.5;
            double i=getbalance()-withdrawalAmount-interest;
            setbalance(i);
        }
    }
    void charge(){
        if(getbalance()<1000.0){
            double pay=(1000.0-getbalance())*0.02;
            setbalance(getbalance()-pay);
        }
    }
    
};
class BasicAccount extends BankAccount{
    private double checkAmount;
    private int countChecks;
    private int checkbookNo;
    BasicAccount(int a,String b,String c,String d,double e,double f,int g,int h){
        super(a,b,c,d,e);
        checkAmount=f;
        countChecks=g;
        checkbookNo=h;
    }
    void charge(){
        if(countChecks>10){
            double pay=(countChecks-10)*50.0;
            setbalance(getbalance()-pay);
        }
    }
    void show(){
        System.out.println("accountNumber:"+getAccount()+" holderName:"+getHolder()+" holderType:"+getType()+" bankName:"+getbank()+" balance:"+getbalance()+" checkAmount:"+checkAmount+" countChecks:"+countChecks+" checkbookNo"+checkbookNo);
    }
};
class DepositAccount extends BankAccount{
    private double depositAmount;
    private int countChecks;
    DepositAccount(int a,String b,String c,String d,double e,double f,int g){
        super(a,b,c,d,e);
        depositAmount=f;
        countChecks=g;
    }
    void show(){
        System.out.println("accountNumber:"+getAccount()+" holderName:"+getHolder()+" holderType:"+getType()+" bankName:"+getbank()+" balance:"+getbalance()+" depositAmount:"+depositAmount+" countChecks"+countChecks);
    }
    void earninterest(){
        if(getbalance()>20000.0){
            double earn=depositAmount*.5;
            setbalance(getbalance()+earn);
        }
    }
    void check(){
        if(countChecks>3){
            System.out.println("cannot write any more check");
        }
    }
    void imposefee(){
        if(getbalance()<1000.0){
            double fee=(1000.0-getbalance())*0.3;
            setbalance(getbalance()-fee);
        }
    }
}
public class Accountsystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        StudentAccount student=new StudentAccount(11105,"Jannat","temporary","BUET","Full-time");
        student.show();
        SavingsAccount save=new SavingsAccount(10304,"Rahima","permanant","Pubali Bank",25000.0,10000.0,5000.0,2417985);
        BasicAccount basic=new BasicAccount(10082,"Rima","permanant","Sonali Bank",30000.0,3000,6,193795);
        DepositAccount dep=new DepositAccount(15082,"Shima","permanant","Rupali Bank",28000.0,2000,3);
        save.show();
        save.deposit();
        save.withdraw();
        save.charge();
        save.show();
        basic.show();
        basic.charge();
        basic.show();
        dep.show();
        dep.earninterest();
        dep.check();
        dep.imposefee();
        dep.show();
    }
    
}
