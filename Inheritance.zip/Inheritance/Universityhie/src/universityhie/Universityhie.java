/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package universityhie;

/**
 *
 * @author jannat
 */
class Community{
    private String department;
    private String institute;
    Community(String a,String b){
        department=a;
        institute=b;
    }
    void view()
    {
        System.out.println("department:"+department+" institute:"+institute);
    }
};
class Employee extends Community{
    private String name;
    private String employeeID;
    private double salary;
    private double increment;
    Employee(String a,String b,String c,String d,double e,double f){
        super(a,b);
        name=c;
        employeeID=d;
        salary=e;
        increment=f;
    }
    @Override
    void view()
    {
        super.view();
        System.out.println("employee name:"+name+" ID:"+employeeID+" salary:"+salary+" increment:"+increment);
    }
};
class Student extends Community{
    private String name;
    private String studentID;
    private String status;
    Student(String a,String b,String c,String d,String e){
        super(a,b);
        name=c;
        studentID=d;
        status=e;
    }
    @Override
    void view()
    {
        super.view();
        System.out.println("Student name:"+name+" ID:"+studentID+" status:"+status);
    }
};
class Alumny extends Community{
    private String name;
    private int passYear;
    Alumny(String a,String b,String c,int d){
        super(a,b);
        name=c;
        passYear=d;
    }
    @Override
    void view()
    {
        super.view();
        System.out.println("Alumny name:"+name+" passyear:"+passYear);
    }
}
class Faculty extends Employee{
    private int facultycode;
    private String designation;
    private int joinYear;
    Faculty(String a,String b,String c,String d,double e,double f,int g,String h,int i){
        super(a,b,c,d,e,f);
        designation=h;
        facultycode=g;
        joinYear=i;
    }
    @Override
    void view()
    {
        super.view();
        System.out.println("designation:"+designation+" facultycode:"+facultycode+" joinYear:"+joinYear);
    }
};
class Staff extends Employee{
    private int duration;
    private int joinYear;
    Staff(String a,String b,String c,String d,double e,double f,int g,int h){
        super(a,b,c,d,e,f);
        joinYear=g;
        duration=h;
    }
    @Override
    void view()
    {
        super.view();
        System.out.println("duration:"+duration+" joinYear:"+joinYear);
    }
};
class Administrator extends Faculty{
    private String position;
    private double duration;
    Administrator(String a,String b,String c,String d,double e,double f,int g,String h,int i,String j,double k)
    {
        super(a,b,c,d,e,f,g,h,i);
        position=j;
        duration=k;
    }
    @Override
    void view()
    {
        super.view();
        System.out.println("duration:"+duration+" position:"+position);
    }
};
class Teacher extends Faculty{
    private int noCourses;
    private double weeklyHour;
    Teacher(String a,String b,String c,String d,double e,double f,int g,String h,int i,int j,double k)
    {
        super(a,b,c,d,e,f,g,h,i);
        noCourses=j;
        weeklyHour=k;
    }
    @Override
    void view()
    {
        super.view();
        System.out.println("noCourses:"+noCourses+" weeklyHour:"+weeklyHour);
    }
}
public class Universityhie {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Community com;
        Teacher teach=new Teacher("CSE","BUET","Md.Ali","101",30000.0,6000.0,5,"Assistant Professor",2003,3,10.0);
        Administrator ad=new Administrator("CSE","BUET","Rahim","1010",3000.0,500.5,100,"Attendant",1997,"Senior",15.6);
        com=teach;
        com.view();
        com=ad;
        com.view();
    }
    
}
