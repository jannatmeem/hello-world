/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tcpserver;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;

/**
 * FXML Controller class
 *
 * @author jannat
 */


public class ServerController implements Initializable {

    /**
     * Initializes the controller class.
     */
    //public TCPServer ob=new TCPServer();
    
    @FXML
    static TextArea servertext;
    
    @FXML
    private Button start;
    
    @FXML
    public void sendToClient()throws IOException{
        TCP server=new TCP(this);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
class TCP implements Runnable{
   
        int id=1;
        int count=0;
        ServerController ob1;
        public static ServerSocket welcomeSocket;
        Thread t;
        public TCP(ServerController ob) throws IOException{
            
            t=new Thread(this);
            this.ob1=ob;
            
            t.start();
            
        // TODO code application logic here
        }
        public void run(){
            try {
                welcomeSocket = new ServerSocket(5678);
            } catch (IOException ex) {
                //Logger.getLogger(TCP.class.getName()).log(Level.SEVERE, null, ex);
            }
            while(true)
            {
                try{
                    Socket connectionSocket = welcomeSocket.accept();
                    WorkerThread wt = new WorkerThread(connectionSocket,id,ob1);
                    Thread t = new Thread(wt);
                    t.start();
                    count++;
                    System.out.println("Client : "+id+"got connected. Total threads : "+count);
                    id++;
                }catch(Exception e){
                    
                }
            }
        }


    class WorkerThread implements Runnable
    {
        private int id;
        private Socket connectionSocket;
        ServerController ob1;
        public WorkerThread(Socket connectionSocket, int id,ServerController ob) 
        {
            this.id=id;
            this.connectionSocket=connectionSocket;
            this.ob1=ob;
        }

        public void run()
        {
            String s1;
            String s2;
            try
            {
                BufferedReader inFromClient = new BufferedReader(
                    new InputStreamReader(connectionSocket.getInputStream()));
                DataOutputStream toClient = new DataOutputStream(connectionSocket.getOutputStream());

                while(true)
                {
                    s1=inFromClient.readLine();
                    s2=s1.toUpperCase();
                    ob1.servertext.appendText("Client ["+id+"] said: "+s1+'\n');
                    toClient.writeBytes(s2+'\n');
                }

            }
            catch(Exception e)
            {

            }


        }
    }
}
