/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tcpclient;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.io.IOException;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author jannat
 */
public class TCPClient extends Application {
    static Stage primary;
    
    @Override
    public void start(Stage a) throws IOException {
        primary=a;
        showFrontPage();
    }
    
    public void showFrontPage() throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("client.fxml"));
        
        Scene scene = new Scene(root, 900, 600);
        
        primary.setTitle("Client");
        primary.setScene(scene);
        primary.show();
    }
    
    
    public static void main(String[] args) {
        launch(args);
    }
    
}
