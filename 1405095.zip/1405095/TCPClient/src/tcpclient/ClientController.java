/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tcpclient;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import static tcpclient.TCPClient.primary;

/**
 * FXML Controller class
 *
 * @author jannat
 */
public class ClientController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private TextArea getfromserver;
    
    @FXML
    private TextField writefromclient;
    
    @FXML
    private Button Send;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    } 
    public void sendToServer() throws IOException{
        Socket clientSocket = new Socket("localhost",5678);
        BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
        BufferedReader inFromServer = new BufferedReader(
                new InputStreamReader(clientSocket.getInputStream()));
        DataOutputStream toServer = new DataOutputStream(clientSocket.getOutputStream());
        String s1;
        String s2;
        try {
            s1=writefromclient.getText();
            toServer.writeBytes(s1 + '\n');
            s2 = inFromServer.readLine();
            getfromserver.appendText("From Server : "+s2+'\n');
        } catch (IOException e) {
                clientSocket.close();
                getfromserver.appendText("Server Connection Lost\n");
        }

        writefromclient.clear();

    }
    
}
